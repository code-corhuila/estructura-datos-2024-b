package com.Corhuila.Parque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
